﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace _20210104032_assignment_1.Models
{
    public class Details
    {
        [Required(ErrorMessage = "Full Name is required")]
        public string Fullname { get; set; }

        [Required(ErrorMessage = "Phone Number is required")]
        [RegularExpression(@"^\d{10}$", ErrorMessage = "Invalid Phone Number")]
        public string Phonenumber { get; set; }

        [Required(ErrorMessage = "Age is required")]
        [Range(18, 500, ErrorMessage = "Age must be above 18")]
        public int Age { get; set; }

        [Required(ErrorMessage = "Gender is required")]
        public string Gender { get; set; }
    }

}