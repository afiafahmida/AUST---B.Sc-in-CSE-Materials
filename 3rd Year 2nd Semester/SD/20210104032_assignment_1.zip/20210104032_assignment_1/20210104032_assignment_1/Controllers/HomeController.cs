﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;
using _20210104032_assignment_1.Models;


namespace _20210104032_assignment_1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Hi, this is Afia Fahmida";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }


        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

       

        [HttpPost]
        public ActionResult Login(string username, string password)
        {

            
            if (username == "sun" && password == "s123")
            {
                //ViewBag.signed = true;
                FormsAuthentication.SetAuthCookie(username, false);
                return RedirectToAction("Details");
            }
            else
            {
                ViewBag.Errormsg = "Invalid user";
                return View();
            }
        }

        public ActionResult Logout()
        {
            //FormsAuthentication.SignOut();
            //ViewBag.signed = false;
            //return RedirectToAction("Login", "Home");
            ViewBag.signed = false;
            return RedirectToAction("Login");
        }

        //[Authorize]
        public ActionResult Details()
        {
            ViewBag.signed = true;
            return View();

        }

        [HttpPost]
        //[Authorize]
        public ActionResult SubmitDetails(string fullName, string phoneNumber, int age, string gender)
        {
            ViewBag.DetailsSubmitted = true;
            ViewBag.FullName = fullName;
            ViewBag.PhoneNumber = phoneNumber;
            ViewBag.Age = age;
            ViewBag.Gender = gender;

            return View("Index");
           
        }

     



    }
}