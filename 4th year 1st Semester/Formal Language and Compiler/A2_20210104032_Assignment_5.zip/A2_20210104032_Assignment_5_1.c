#include <stdio.h>
#include <string.h>
#include <stdbool.h>

/*
  A → aXd
  X → bbX
  X → bcX
  X → epsilon
*/


bool startSymbol(const char input[], int *pos);
bool sequence(const char input[], int *pos);

// Function definitions must match the prototypes
bool startSymbol(const char input[], int *pos)
{
    if (*pos >= strlen(input)) return false;
    if (input[*pos] == 'a')
    {
        (*pos)++;
        if (sequence(input, pos))
        {
            if (*pos < strlen(input) && input[*pos] == 'd')
            {
                (*pos)++;
                return true;
            }
        }
    }
    return false;
}

bool sequence(const char input[], int *pos)
{
    if (*pos >= strlen(input)) return true; // X → ε
    if (*pos + 1 < strlen(input) && input[*pos] == 'b' && input[*pos + 1] == 'b')
    {
        *pos += 2;
        return sequence(input, pos);
    }
    if (*pos + 1 < strlen(input) && input[*pos] == 'b' && input[*pos + 1] == 'c')
    {
        *pos += 2;
        return sequence(input, pos);
    }
    return true;
}

int main()
{
    char input[100];

    while(1)
    {
        printf("Enter a string: ");
        scanf("%s", input);

        int pos = 0;
        if (startSymbol(input, &pos) && pos == strlen(input))
        {
            printf("Valid string \n\n");
        }
        else
        {
            printf("Invalid string \n\n");
        }
    }
    return 0;
}
