#include <stdio.h>
#include <stdlib.h>

void error()
{
    printf("Invalid expression\n");
    exit(1);
}

void Expression()
{
    Term();
    while (1)
    {
        char op = getchar();
        if (op == '+' || op == '-')
        {
            Term();
        }
        else
        {
            ungetc(op, stdin);
            break;
        }
    }
}

void Term()
{
    Factor();
    while (1)
    {
        char op = getchar();
        if (op == '*' || op == '/')
        {
            Factor();
        }
        else
        {
            ungetc(op, stdin);
            break;
        }
    }
}

void Factor()
{
    char symbol = getchar();
    if (symbol == '(')
    {
        Expression();
        check(')');
        return;
    }
    else if ((symbol >= 'a' && symbol <= 'z') || (symbol >= '0' && symbol <= '9'))
    {
        return;
    }
    else
    {
        error();
    }
}

void check(char symbol)
{
    char input;
    scanf(" %c", &input);
    if (input != symbol)
    {
        error();
    }
}

int main()
{
    while(1)
    {
        printf("Enter the string: ");
        Expression();

        if (getchar() != '\n')
        {
            error();
        }

        printf("Valid expression\n");
    }

    return 0;
}
